<?php require "header.php" ?>   
        <!-- ========== REVOLUTION SLIDER ========== -->
        <section id="slider" class="full_slider">
            <div class="rev_slider_wrapper fullscreen-container">
                <div id="fullscreen_slider" class="rev_slider fullscreenbanner gradient_slider" style="display:none">
                    <ul>
                        
                        <!-- SLIDE NR. 1 -->  
                        <li data-transition="fade">
                            <!-- MAIN IMAGE -->
                            <img src="images/slider/full-slider-1.jpg" 
                                 alt="Image" 
                                 title="slider_bg1-1" 
                                 data-bgposition="center center" 
                                 data-bgfit="cover" 
                                 data-bgrepeat="no-repeat" 
                                 data-bgparallax="10" 
                                 class="rev-slidebg" 
                                 data-no-retina="">
                             <!-- LAYER NR. 1 -->
                            <div class="tp-caption tp-resizeme"
                                 data-x="center" 
                                 data-hoffset="" 
                                 data-y="middle" 
                                 data-voffset="['-30','-30','-30','-30']" 
                                 data-responsive_offset="on" 
                                 data-fontsize="['60','50','40','30']" 
                                 data-lineheight="['60','50','40','30']"
                                 data-whitespace="nowrap" 
                                 data-frames='[{"delay":1000,"speed":2000,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":500,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                                 style="z-index: 5; color: #fff; font-weight: 900;"> LUXURY TOUCH HOTEL.
                            </div>
                            <!-- LAYER NR. 2 -->
                            <div class="tp-caption tp-resizeme"
                                 data-x="center" 
                                 data-hoffset="" 
                                 data-y="middle" 
                                 data-voffset="['45','45','45','45']"
                                 data-fontsize="['16', '16', '14', '12']" 
                                 data-lineheight="['16', '16', '14', '12']" 
                                 data-whitespace="nowrap" 
                                 data-transform_idle="o:1;"
                                 data-transform_in="opacity:0;s:300;e:Power2.easeInOut;" 
                                 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                 data-start="3000" 
                                 data-splitin="chars" 
                                 data-splitout="none" 
                                 data-basealign="slide" 
                                 data-responsive="off" 
                                 data-elementdelay="0.05"
                                 style="z-index: 9; font-weight: 400; color: rgba(255, 255, 255, 0.8); font-family: Raleway;">FEEL THE CLASS
                            </div>   
                        </li>

                        <!-- SLIDE NR. 2 -->
                        <li data-transition="fade" 
                            data-slotamount="7"  
                            data-easein="default" 
                            data-easeout="default" 
                            data-masterspeed="1000">
                            <!-- MAIN IMAGE -->
                            <img src="images/slider/full-slider-2.jpg" 
                                 alt="Image" 
                                 title="slider_bg1-2"
                                 data-bgposition="center center" 
                                 data-bgfit="cover" 
                                 data-bgrepeat="no-repeat" 
                                 data-bgparallax="10" 
                                 class="rev-slidebg" 
                                 data-no-retina="">
                            <!-- LAYER NR. 1 -->
                            <div class="tp-caption tp-resizeme"
                                 data-x="center" 
                                 data-hoffset="" 
                                 data-y="middle" 
                                 data-voffset="['-30','-30','-30','-30']" 
                                 data-responsive_offset="on" 
                                 data-fontsize="['60','50','40','30']" 
                                 data-lineheight="['60','50','40','30']"
                                 data-whitespace="nowrap" 
                                 data-frames='[{"delay":1000,"speed":2000,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":500,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                                 style="z-index: 5; color: #fff; font-weight: 900;">WE ARE PLEASED TO HOST YOU.
                            </div>
                            <!-- LAYER NR. 2 -->
                            <div class="tp-caption tp-resizeme"
                                 data-x="center" 
                                 data-hoffset="" 
                                 data-y="middle" 
                                 data-voffset="['45','45','45','45']"
                                 data-fontsize="['16', '16', '14', '12']" 
                                 data-lineheight="['16', '16', '14', '12']" 
                                 data-whitespace="nowrap" 
                                 data-transform_idle="o:1;"
                                 data-transform_in="opacity:0;s:300;e:Power2.easeInOut;" 
                                 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                 data-start="3000" 
                                 data-splitin="chars" 
                                 data-splitout="none" 
                                 data-basealign="slide" 
                                 data-responsive="off" 
                                 data-elementdelay="0.05"
                                 style="z-index: 9; font-weight: 400; color: rgba(255, 255, 255, 0.8); font-family: Raleway;">Take A Tour of Our Site.

                            </div>   
                            
                        </li>
                        
                        <!-- SLIDE NR. 3 -->
                        <li data-transition="fade" 
                            data-slotamount="7"  
                            data-easein="default" 
                            data-easeout="default" 
                            data-masterspeed="1000">
                            <!-- MAIN IMAGE -->
                            <img src="images/slider/full-slider-3.jpg" 
                                 alt="Image" 
                                 title="slider_bg1-3"
                                 data-bgposition="center center"
                                 data-bgfit="cover" 
                                 data-bgrepeat="no-repeat" 
                                 data-bgparallax="10" 
                                 class="rev-slidebg"
                                 data-no-retina="">
                            <!-- LAYER NR. 1 -->
                            <div class="tp-caption tp-resizeme"
                                 data-x="center" 
                                 data-hoffset="" 
                                 data-y="middle" 
                                 data-voffset="['-30','-30','-30','-30']" 
                                 data-responsive_offset="on" 
                                 data-fontsize="['60','50','40','30']" 
                                 data-lineheight="['60','50','40','30']"
                                 data-whitespace="nowrap" 
                                 data-frames='[{"delay":1000,"speed":2000,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":500,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                                 style="z-index: 5; color: #fff; font-weight: 900;">BOOK YOUR STAY
                            </div>
                            <!-- LAYER NR. 2 -->
                            <div class="tp-caption tp-resizeme"
                                   data-x="['center','center','center','center']" 
                                 data-hoffset="" 
                                 data-y="['middle','middle','middle','middle']" 
                                 data-voffset="['45','45','45','45']"
                                 data-fontsize="['16', '16', '14', '12']" 
                                 data-lineheight="['16', '16', '14', '12']" 
                                 data-whitespace="nowrap" 
                                 data-transform_idle="o:1;"
                                 data-transform_in="opacity:0;s:300;e:Power2.easeInOut;" 
                                 data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                 data-mask_out="x:inherit;y:inherit;s:inherit;e:inherit;" 
                                 data-start="3000" 
                                 data-splitin="chars" 
                                 data-splitout="none" 
                                 data-basealign="slide" 
                                 data-responsive="off" 
                                 data-elementdelay="0.05"
                                 style="z-index: 9; font-weight: 400; color: rgba(255, 255, 255, 0.8); font-family: Raleway;">Rooms Starting from GHC200 only
                            </div>   
                        </li>
                        
                    </ul>
                </div>
            </div>
              <!-- ========== BOOKING FORM ========== -->
              <div class="hbf_2">
                <div class="container">
                    <div class="inner">
                        <form id="booking-form">
                            <div class="col-md-2 md_pr5">
                                <div class="form-group">
                                    <input name="booking-email" type="text" id="email" value="" class="form-control" placeholder="Your Email Address">
                                </div>
                            </div>
                            <div class="col-md-2 md_p5">
                                <div class="form-group">
                                    <div class="form_select">
                                        <select name="booking-roomtype" class="form-control" title="Select Room Type" data-header="Room Type">
                                            <option value="Single">Single Room</option>
                                            <option value="Double">Double Room</option>
                                            <option value="Deluxe">Deluxe Room</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 arrival_date md_pl5 md_nopadding_right">
                                        <div class="form-group">
                                            <div class="form_date">
                                                <input type="text" class="datepicker form-control md_noborder_right" name="booking-checkin" placeholder="Arrival Date" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 departure_date md_pr5 md_nopadding_left">
                                        <div class="form-group">
                                            <div class="form_date departure">
                                                <input type="text" class="datepicker form-control" name="booking-checkout" placeholder="Departure Date" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 adults md_pl5 md_nopadding_right">
                                        <div class="form-group">
                                            <div class="form_select">
                                                <select name="booking-adults" class="form-control md_noborder_right" title="Adults" data-header="Adults">
                                                    <option value="0">0</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 children md_pr5 md_nopadding_left">
                                        <div class="form-group">
                                            <div class="form_select childrens_select">
                                                <select name="booking-children" class="form-control dropup" title="Children" data-header="Children">
                                                    <option value="0">0</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2 md_pl5">
                                <button type="submit" class="button  btn_red btn_full">BOOK NOW!</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!-- ========== About Us ========== -->

        <!-- ========== ROOMS ========== -->

        <section class="white_bg" id="rooms">
            <div class="container">
                <div class="main_title mt_wave  a_center">
                    <h2 style="color: #f61f2a;">OUR FAVORITE ROOMS</h2>
                </div> 
                    <p class="main_description a_center">Our rooms standout, we wont say much, see for yourself.</p> 
                <div class="row">
                    <div class="col-md-4">
                        <article class="room">
                            <figure>
                                <div class="price">GH89 <span>/ night</span></div>
                                <a class="hover_effect h_blue h_link" href="room.html">
                                    <img src="images/rooms/single-room.jpg" class="img-responsive" alt="Image">
                                </a>
                                <figcaption>
                                    <h4><a href="room.html">Single Room</a></h4>
                                    <span class="f_right"><a href="room.php" class="button btn_sm btn_yellow">VIEW DETAILS</a></span>
                                </figcaption>
                            </figure>
                        </article>
                    </div>
                    <div class="col-md-4">
                        <article class="room">
                            <figure>
                                <div class="price">GH129 <span>/ night</span></div>
                                <a class="hover_effect h_blue h_link" href="room.html">
                                    <img src="images/rooms/double-room.jpg" class="img-responsive" alt="Image">
                                </a>
                                <figcaption>
                                    <h4><a href="room.html">Double Room</a></h4>
                                    <span class="f_right"><a href="room.php" class="button btn_sm btn_yellow">VIEW DETAILS</a></span>
                                </figcaption>
                            </figure>
                        </article>
                    </div>
                    <div class="col-md-4">
                        <article class="room">
                            <figure>
                                <div class="price">GH189 <span>/ night</span></div>
                                <a class="hover_effect h_blue h_link" href="room.html">
                                    <img src="images/rooms/deluxe-room.jpg" class="img-responsive" alt="Image">
                                </a>
                                <figcaption>
                                    <h4><a href="room.html">Delux Room</a></h4>
                                    <span class="f_right"><a href="room.php" class="button btn_sm btn_yellow">VIEW DETAILS</a></span>
                                </figcaption>
                            </figure>
                        </article>
                    </div>
                </div>
                <div class="mt40 a_center">
                    <a class="button btn_sm btn_yellow" href="rooms-grid.php">VIEW ROOMS LIST</a>
                </div>
            </div>
        </section>

        <!-- ========== FEATURES ========== -->
        <section class="lightgrey_bg" id="features">
            <div class="container">
                <div class="main_title mt_wave mt_red a_center">
                    <h2 style="color: #f61f2a;">OUR AWESOME SERVICES</h2>
                </div>
                <p class="main_description a_center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit.</p>
                
                <div class="row">
                    <div class="col-md-7">
                        <div data-slider-id="features" id="features_slider" class="owl-carousel">
                            <div><img src="images/restaurant.jpg" class="img-responsive" alt="Image"></div>
                            <div><img src="images/spa.jpg" class="img-responsive" alt="Image"></div>
                            <div><img src="images/conference.jpg" class="img-responsive" alt="Image"></div>
                            <div><img src="images/swimming.jpg" class="img-responsive" alt="Image"></div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="owl-thumbs" data-slider-id="features">
                            <div class="owl-thumb-item">
                                <span class="media-left"><i class="flaticon-food"></i></span>
                                <div class="media-body">
                                    <h5>Restaurant</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.</p>
                                </div>
                            </div>
                            <div class="owl-thumb-item">
                                <span class="media-left"><i class="flaticon-person"></i></span>
                                <div class="media-body">
                                    <h5>Executive Bar</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.</p>
                                </div>
                            </div>
                            <div class="owl-thumb-item">
                                <span class="media-left"><i class="flaticon-business"></i></span>
                                <div class="media-body">
                                    <h5>Conference Room</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.</p>
                                </div>
                            </div>
                            <div class="owl-thumb-item">
                                <span class="media-left"><i class="flaticon-beach"></i></span>
                                <div class="media-body">
                                    <h5>Swimming Pool</h5>
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
     
        <!-- ========== ABOUT ========== -->
     

        <!-- ========== GALLERY ========== -->

        <section id="gallery" class="blue_bg">
                <div class="container">
                    <div class="main_title mt_wave mt_white a_center">
                        <h2>LUXRURY TOUCH GALLERY PHOTOS</h2>
                    </div> 
                        <p class="main_description md_white a_center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit.</p> 
                </div>
                <div id="gallery_slider" class="owl-carousel image-gallery">
                    <!-- ITEM -->
                    <div class="item">
                        <a class="hover_effect h_yellow h_lightbox" href="images/gallery/gallery1.jpg">
                            <img src="images/gallery/gallery1.jpg" alt="Image">
                        </a>
                        <div class="gallery_item_info">
                            <h4>Rooms Service</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <a class="hover_effect h_yellow h_lightbox" href="images/gallery/gallery2.jpg">
                            <img src="images/gallery/gallery2.jpg" alt="Image">
                        </a>
                        <div class="gallery_item_info">
                            <h4>Rooms Service</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <a class="hover_effect h_yellow h_lightbox" href="images/gallery/gallery3.jpg">
                            <img src="images/gallery/gallery3.jpg" alt="Image">
                        </a>
                        <div class="gallery_item_info">
                            <h4>Rooms Service</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <a class="hover_effect h_yellow h_lightbox" href="images/gallery/gallery4.jpg">
                            <img src="images/gallery/gallery4.jpg" alt="Image">
                        </a>
                        <div class="gallery_item_info">
                            <h4>Rooms Service</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <a class="hover_effect h_yellow h_lightbox" href="images/gallery/gallery5.jpg">
                            <img src="images/gallery/gallery5.jpg" alt="Image">
                        </a>
                        <div class="gallery_item_info">
                            <h4>Rooms Service</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <a class="hover_effect h_yellow h_lightbox" href="images/gallery/gallery6.jpg">
                            <img src="images/gallery/gallery6.jpg" alt="Image">
                        </a>
                        <div class="gallery_item_info">
                            <h4>Rooms Service</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <a class="hover_effect h_yellow h_lightbox" href="images/gallery/gallery7.jpg">
                            <img src="images/gallery/gallery7.jpg" alt="Image">
                        </a>
                        <div class="gallery_item_info">
                            <h4>Rooms Service</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <a class="hover_effect h_yellow h_lightbox" href="images/gallery/gallery8.jpg">
                            <img src="images/gallery/gallery8.jpg" alt="Image">
                        </a>
                        <div class="gallery_item_info">
                            <h4>Rooms Service</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                        </div>
                    </div>
                    <!-- END ITEM -->
                </div>

                <div class="container">
                    <div class="mt40 a_center">
                        <a class="button btn_sm btn_dark upper" href="gallery3.php">View Full Gallery</a>
                    </div>
                </div>

            </section>


        <!-- ========== GALLERY ========== -->
                    <!-- ========== TESTIMONIALS ========== -->
                    <section id="testimonials_style_2" class="grey_bg">
                <div class="container">
                    <div class="main_title mt_wave a_center">
                        <h2>WHAT PEOPLE SAY ABOUT US</h2>
                    </div> 
                        <p class="main_description a_center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit.</p> 
                    <div class="row">
                        <!-- ITEM -->
                        <div class="col-md-4">
                            <div class="review_item">
                                <div class="review_content">
                                    <h3>Excellent! </h3>
                                    <div class="review_rating">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star-o" aria-hidden="true"></i>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                                </div>
                                <div class="review_author">
                                    <img src="images/users/user1.jpg" alt="Image">
                                    <div class="author_info">
                                        <h5>Micheal Manu</h5>
                                        <span class="place">Goldfields,Tarkwa </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ITEM -->
                        <div class="col-md-4">
                            <div class="review_item">
                                <div class="review_content">
                                    <h3>Excellent! </h3>
                                    <div class="review_rating">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                                </div>
                                <div class="review_author">
                                    <img src="images/users/user2.jpg" alt="Image">
                                    <div class="author_info">
                                        <h5>Mrs. Manu</h5>
                                        <span class="place">Anglo Gold, Tarkwa</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ITEM -->
                        <div class="col-md-4">
                            <div class="review_item">
                                <div class="review_content">
                                    <h3>Excellent! </h3>
                                    <div class="review_rating">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star-o" aria-hidden="true"></i>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                                </div>
                                <div class="review_author">
                                    <img src="images/users/user3.jpg" alt="Image">
                                    <div class="author_info">
                                        <h5>Mr. Essel</h5>
                                        <span class="place">Nsuta, Tarkwa</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        <!-- ========== BLOG ========== -->

        <main id="our_staff_page">
            <div class="container">
                <div class="main_title mt_wave mt_red a_center">
                    <h2 style="color: #f61f2a;" >OUR STAFF IS READY TO SERVE YOU!</h2>
                </div>
                <p class="main_description a_center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit.</p>
                <div class="row">

                    <!-- ITEM -->
                    <div class="col-md-3 col-sm-6">
                        <div class="item">
                            <a href="#" class="hover_effect h_blue h_link">
                                <img src="images/staff/staff1.jpg" class="img-responsive" alt="Image">
                            </a>
                            <h5>Claud Ankrah<small>CEO</small></h5>
                            <p>The brain behind Luxury Touch, the man with vision.</p>
                            <div class="social-media">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="col-md-3 col-sm-6">
                        <div class="item">
                            <a href="#" class="hover_effect h_blue h_link">
                                <img src="images/staff/staff2.jpg" alt="Image">
                            </a>
                            <h5>Mark Anderson<small>Hotel Manager</small></h5>
                            <p>Lorem Ipsum which looks many web sites pass websites is therefore always.</p>
                            <div class="social-media">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="col-md-3 col-sm-6">
                        <div class="item">
                            <a href="#" class="hover_effect h_blue h_link">
                                <img src="images/staff/staff3.jpg" alt="Image">
                            </a>
                            <h5>Peter Adu<small>Chef</small></h5>
                            <p>Lorem Ipsum which looks many web sites pass websites is therefore always.</p>
                            <div class="social-media">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="col-md-3 col-sm-6">
                        <div class="item">
                            <a href="#" class="hover_effect h_blue h_link">
                                <img src="images/staff/staff4.jpg" alt="Image">
                            </a>
                            <h5>Samuel Mason<small>Head of Security</small></h5>
                            <p>Lorem Ipsum which looks many web sites pass websites is therefore always.</p>
                            <div class="social-media">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="mt40 a_center">
                    <a class="button btn_sm btn_yellow" href="our-staff.php">CHECK THE WHOLE TEAM OUT</a>
                </div>
            </div>
        </main>


        
        <!-- ========== CONTACT ========== -->
        <section class="white_bg" id="contact">
            <div class="container">
                <div class="main_title mt_wave  a_center">
                    <h2 style="color: #f61f2a;">LOCATION - CONTACT US</h2>
                </div>
                <p class="main_description a_center">Do you have a question? Or you want to give us your very appreciated and anonymous review? Feel free to send us an email. </p>
                <div class="row">
                    <div class="col-md-6">
                        <div id="map-canvas"></div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="contact-items">
                                <div class="col-md-4 col-sm-3">
                                    <div class="contact-item">
                                        <i class="glyphicon glyphicon-map-marker"></i>
                                        <h6>Agric Hills - Tarkwa</h6>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-3">
                                    <div class="contact-item">
                                        <i class="glyphicon glyphicon-phone-alt"></i>
                                        <h6>0544543433</h6>
                                    </div>
                                </div>
                                <div class="col-md-5 col-sm-4">
                                    <div class="contact-item">
                                        <i class="fa fa-envelope"></i>
                                        <h6>info@luxurytouchhotel.com</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form id="contact-form" name="contact-form">
                            <div id="contact-result"></div>
                            <div class="form-group">
                                <input class="form-control" name="name" placeholder="Your Name" type="text">
                            </div>
                            <div class="form-group">
                                <input class="form-control" name="email" type="email" placeholder="Your Email Address">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="message" placeholder="Your Message"></textarea>
                            </div>
                            <button class="button btn_lg btn_red btn_full upper" type="submit"><i class="fa fa-location-arrow"></i>Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
            
        <!-- ========== FOOTER ========== -->
<?php  require "footer.php"?>